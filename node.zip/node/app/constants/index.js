module.exports = {
    onchainStatus : {
        success: "SUCCESS",
        error: "ERROR"
    }
}